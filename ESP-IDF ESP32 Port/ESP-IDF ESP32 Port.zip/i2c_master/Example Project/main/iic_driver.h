//enable iic driver
#if 1
#ifndef IIC_DRIVER_H
#define IIC_DRIVER_H

//include
#include "driver/i2c_master.h"

//iic init
void iic_init();

#endif//#ifndef IIC_DRIVER_H
#endif//#if 1